package arbolesBinarios;
public class Arbol {
	Nodo raiz;
	//----------------------------------------------
	//        Constructores de la clase
	//----------------------------------------------
	public Arbol() {
		raiz=null;
	}
	public Arbol(Nodo nodo) {
		raiz=nodo;
	}
	//----------------------------------------------
	//       Operaciones para insertar los nodos
	//----------------------------------------------
	public boolean ArbolVacio() {
		if(raiz==null) {
			return true;
		}
		return false;
	}
	public void insertar(Datos dato) {
	    if (ArbolVacio()) {
	        Nodo nodo = new Nodo(dato);
	        raiz = nodo;
	    } else {
	        Nodo nodoNuevo = new Nodo(dato);
	        Nodo padre = null;
	        Nodo actual = raiz;
	        
	        while (actual != null) {
	            padre = actual;
	            //? es un operador ternario, que me permite optimizar una condicional
	            //(confición) "?"<-- else if  (true condición): (false condición)
	            actual = (nodoNuevo.getDato().getCedula() < actual.getDato().getCedula()) ? actual.getIzquierda() : actual.getDerecha();
	        }
	        
	        if (nodoNuevo.getDato().getCedula() < padre.getDato().getCedula()) {
	            padre.setIzquierda(nodoNuevo);
	        } else {
	            padre.setDerecha(nodoNuevo);
	        }        
	        nodoNuevo.setPadre(padre);
	    }
	}
	//-----------------------------------------------------------
	//                     Mostrar el árbol
	//-----------------------------------------------------------
	public void mostrarInOrden(Nodo nodo) {
	    if (nodo != null) {
	        mostrarInOrden(nodo.getIzquierda());    // Recorrer el subárbol izquierdo
	        System.out.println(nodo.getDato().getCedula());// Mostrar el nodo actual
	        mostrarInOrden(nodo.getDerecha());      // Recorrer el subárbol derecho
	    }
	}
	public Nodo getRaiz() {
		return raiz;
	}
	public void setRaiz(Nodo raiz) {
		this.raiz = raiz;
	}
	
}
