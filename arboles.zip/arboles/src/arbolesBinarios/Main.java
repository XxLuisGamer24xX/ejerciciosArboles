package arbolesBinarios;

public class Main {
    public static void main(String[] args) {
        // Crear el árbol
        Arbol arbol = new Arbol();
        Double precio=222.2;
        // Insertar nodos en el árbol
        Datos dato1= new Datos("Juan","guachilema","negro","kia",precio,5);
        Datos dato2= new Datos("Pedro","guachilema","negro","kia",precio,1);
        Datos dato3= new Datos("Maria","guachilema","negro","kia",precio,2);
        Datos dato4= new Datos("Ana","guachilema","negro","kia",precio,3);
        Datos dato5= new Datos("Carlos","guachilema","negro","kia",precio,6);
        Datos dato6= new Datos("Luis","guachilema","negro","kia",precio,7);
        arbol.insertar(dato1);
        arbol.insertar(dato2);
        arbol.insertar(dato3);
        arbol.insertar(dato4);
        arbol.insertar(dato5);
        arbol.insertar(dato6);

        // Mostrar los elementos en orden ascendente
        arbol.mostrarInOrden(arbol.getRaiz());
    }
}

